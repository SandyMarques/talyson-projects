
const AboutSection = () => {
  return (
    <section id="sobre" className="py-16 md:py-20 bg-sakura-marfim">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl md:text-4xl text-sakura-vermelho text-center mb-10 md:mb-12">Sobre Nós</h2>
        
        <div className="grid md:grid-cols-2 gap-8 items-center">
          <div className="order-2 md:order-1">
            <div className="bg-sakura-rosa p-6 md:p-8 rounded-xl border-l-4 border-sakura-vermelho shadow-sm">
              <p className="text-lg mb-4">
                Fundado em 2012, o Sakura Bistrô mescla técnicas tradicionais japonesas com ingredientes frescos locais, proporcionando uma experiência gastronômica autêntica e contemporânea.
              </p>
              <p className="text-lg mb-4">
                Nossa equipe é liderada pelo chef Takeshi Yamamoto, com mais de 20 anos de experiência na culinária japonesa. Cada prato é preparado com atenção aos detalhes e respeito às tradições.
              </p>
              <p className="text-lg">
                Nossa missão é trazer um pedacinho do Japão para sua mesa, com sabores autênticos e apresentação impecável.
              </p>
            </div>
            
            <div className="mt-6 grid grid-cols-3 gap-3">
              <div className="bg-sakura-rosa p-4 rounded-lg text-center">
                <p className="text-2xl font-bold text-sakura-vermelho">2012</p>
                <p className="text-sm">Fundação</p>
              </div>
              <div className="bg-sakura-rosa p-4 rounded-lg text-center">
                <p className="text-2xl font-bold text-sakura-vermelho">100+</p>
                <p className="text-sm">Pratos</p>
              </div>
              <div className="bg-sakura-rosa p-4 rounded-lg text-center">
                <p className="text-2xl font-bold text-sakura-vermelho">15k+</p>
                <p className="text-sm">Clientes</p>
              </div>
            </div>
          </div>
          
          <div className="order-1 md:order-2">
            <img
              src="https://images.unsplash.com/photo-1617196034183-421b4917c92d?auto=format&fit=crop&w=800&q=70"
              alt="Chef preparando sushi"
              className="rounded-xl shadow-lg w-full h-[400px] object-cover"
            />
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;
