
import MenuItem from './MenuItem';

const MenuSection = () => {
  const menuItems = [
    {
      image: "https://images.unsplash.com/photo-1606787366850-de6330128bfc?auto=format&fit=crop&w=800&q=70",
      alt: "Combo Sushi Variado",
      title: "Combo Sushi Variado",
      description: "20 peças selecionadas dos melhores cortes.",
      price: "R$ 49,90"
    },
    {
      image: "https://images.unsplash.com/photo-1553621045-2c71fefe030e?auto=format&fit=crop&w=800&q=70",
      alt: "Sashimi de Salmão",
      title: "Sashimi de Salmão",
      description: "8 fatias de salmão fresco, cortadas à perfeição.",
      price: "R$ 34,90"
    },
    {
      image: "https://images.unsplash.com/photo-1600891963953-327c44549f31?auto=format&fit=crop&w=800&q=70",
      alt: "Temaki Especial", 
      title: "Temaki Especial",
      description: "Cone de alga, arroz e recheio generoso de salmão.",
      price: "R$ 24,90"
    },
    {
      image: "https://images.unsplash.com/photo-1618160702438-9b02ab6515c9?auto=format&fit=crop&w=800&q=70",
      alt: "Hot Roll",
      title: "Hot Roll",
      description: "8 peças de sushi empanado e frito, com molho especial.",
      price: "R$ 29,90"
    },
    {
      image: "https://images.unsplash.com/photo-1617196034183-421b4917c92d?auto=format&fit=crop&w=800&q=70",
      alt: "Uramaki Filadélfia",
      title: "Uramaki Filadélfia",
      description: "8 peças com salmão, cream cheese e cebolinha.",
      price: "R$ 32,90"
    },
    {
      image: "https://images.unsplash.com/photo-1611143669185-af224c5e3252?auto=format&fit=crop&w=800&q=70",
      alt: "Chirashi",
      title: "Chirashi",
      description: "Tigela com arroz, peixe fresco e legumes variados.",
      price: "R$ 45,90"
    }
  ];

  return (
    <section id="menu" className="py-16 md:py-20">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl md:text-4xl text-sakura-vermelho text-center mb-10 md:mb-12">Nosso Menu</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
          {menuItems.map((item, index) => (
            <MenuItem
              key={index}
              image={item.image}
              alt={item.alt}
              title={item.title}
              description={item.description}
              price={item.price}
            />
          ))}
        </div>
        
        <div className="text-center mt-10">
          <a 
            href="#contato" 
            className="inline-block bg-sakura-vermelho text-sakura-marfim px-6 py-3 rounded-full font-semibold transition-all duration-300 hover:bg-sakura-vermelhoDark"
          >
            Faça seu pedido
          </a>
        </div>
      </div>
    </section>
  );
};

export default MenuSection;
