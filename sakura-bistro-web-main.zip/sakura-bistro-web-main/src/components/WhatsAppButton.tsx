
const WhatsAppButton = () => {
  return (
    <a 
      href="https://wa.me/5500000000000" 
      target="_blank" 
      rel="noopener" 
      aria-label="Pedido rápido via WhatsApp" 
      className="fixed bottom-6 right-6 z-50 bg-[#25d366] text-white w-14 h-14 rounded-full flex items-center justify-center shadow-lg hover:scale-110 transition-transform duration-300"
    >
      <i className="fa-brands fa-whatsapp text-2xl"></i>
    </a>
  );
};

export default WhatsAppButton;
