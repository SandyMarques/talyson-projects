import { useState, useEffect } from 'react';
import { useIsMobile } from '@/hooks/use-mobile';
import Logo from '@/components/Logo';
import { Cart } from "./Cart";

const Header = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const isMobile = useIsMobile();

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 50) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  const navItems = [
    { href: "#menu", label: "Menu" },
    { href: "#sobre", label: "Sobre Nós" },
    { href: "#contato", label: "Pedidos" }
  ];

  return (
    <header 
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled 
          ? 'py-3 bg-sakura-rosa/95 shadow-md backdrop-blur-sm' 
          : 'py-4 bg-sakura-rosa'
      }`}
    >
      <div className="container mx-auto px-4 md:px-6 flex justify-between items-center">
        <Logo />
        
        <div className="flex items-center gap-4">
          {isMobile ? (
            <>
              <Cart />
              <button 
                className="text-sakura-cinza"
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                aria-label={mobileMenuOpen ? "Fechar menu" : "Abrir menu"}
              >
                {mobileMenuOpen ? (
                  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" className="w-6 h-6">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                ) : (
                  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" className="w-6 h-6">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16m-7 6h7" />
                  </svg>
                )}
              </button>
              
              {mobileMenuOpen && (
                <nav 
                  className="absolute top-full left-0 right-0 bg-sakura-rosa/95 backdrop-blur-sm shadow-md py-3 animate-fade-in"
                  aria-label="Navegação principal"
                >
                  <ul className="flex flex-col items-center gap-4">
                    {navItems.map((item) => (
                      <li key={item.href}>
                        <a 
                          href={item.href} 
                          className="text-sakura-cinza font-semibold hover:text-sakura-vermelho transition-colors duration-300"
                          onClick={() => setMobileMenuOpen(false)}
                        >
                          {item.label}
                        </a>
                      </li>
                    ))}
                  </ul>
                </nav>
              )}
            </>
          ) : (
            <>
              <nav aria-label="Navegação principal">
                <ul className="flex gap-6">
                  {navItems.map((item) => (
                    <li key={item.href}>
                      <a 
                        href={item.href} 
                        className="text-sakura-cinza font-semibold hover:text-sakura-vermelho transition-colors duration-300"
                      >
                        {item.label}
                      </a>
                    </li>
                  ))}
                </ul>
              </nav>
              <Cart />
            </>
          )}
        </div>
      </div>
    </header>
  );
};

export default Header;
