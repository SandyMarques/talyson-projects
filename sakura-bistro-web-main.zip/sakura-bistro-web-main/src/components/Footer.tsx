
const Footer = () => {
  return (
    <footer className="bg-sakura-cinza text-sakura-marfim py-10 md:py-12">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <p className="text-2xl font-bold text-sakura-rosa mb-4">Sakura Bistrô</p>
            <p className="text-sm opacity-80">
              Experimente o verdadeiro sabor da culinária japonesa em um ambiente acolhedor e sofisticado.
            </p>
          </div>
          
          <div>
            <p className="font-semibold text-lg mb-4">Links Rápidos</p>
            <ul className="space-y-2">
              <li><a href="#menu" className="hover:text-sakura-rosa transition-colors">Menu</a></li>
              <li><a href="#sobre" className="hover:text-sakura-rosa transition-colors">Sobre Nós</a></li>
              <li><a href="#contato" className="hover:text-sakura-rosa transition-colors">Contato</a></li>
            </ul>
          </div>
          
          <div>
            <p className="font-semibold text-lg mb-4">Contato</p>
            <ul className="space-y-2">
              <li className="flex items-center gap-2">
                <i className="fa-solid fa-phone text-sm"></i>
                <span>(00) 00000-0000</span>
              </li>
              <li className="flex items-center gap-2">
                <i className="fa-solid fa-envelope text-sm"></i>
                <span>contato@sakurabistro.com</span>
              </li>
              <li className="flex items-center gap-2">
                <i className="fa-solid fa-location-dot text-sm"></i>
                <span>Rua das Cerejeiras, 123</span>
              </li>
            </ul>
          </div>
          
          <div>
            <p className="font-semibold text-lg mb-4">Horários</p>
            <ul className="space-y-2">
              <li>Segunda à Sexta: 11h às 23h</li>
              <li>Sábado e Domingo: 12h às 00h</li>
              <li>Feriados: 12h às 22h</li>
            </ul>
          </div>
        </div>
        
        <hr className="border-gray-700 my-8" />
        
        <div className="flex flex-col md:flex-row justify-between items-center">
          <p>&copy; 2025 Sakura Bistrô — Todos os direitos reservados</p>
          
          <div className="flex gap-6 mt-4 md:mt-0" aria-label="Redes sociais">
            <a href="#" aria-label="Instagram" className="social-link">
              <i className="fa-brands fa-instagram text-xl"></i>
            </a>
            <a href="#" aria-label="Facebook" className="social-link">
              <i className="fa-brands fa-facebook text-xl"></i>
            </a>
            <a href="#" aria-label="Twitter/X" className="social-link">
              <i className="fa-brands fa-x-twitter text-xl"></i>
            </a>
            <a href="#" aria-label="TikTok" className="social-link">
              <i className="fa-brands fa-tiktok text-xl"></i>
            </a>
            <a href="#" aria-label="Telegram" className="social-link">
              <i className="fa-brands fa-telegram text-xl"></i>
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
