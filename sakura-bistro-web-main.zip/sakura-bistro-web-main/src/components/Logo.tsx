
import React from 'react';

const Logo = () => {
  return (
    <div className="flex items-center gap-2">
      <img 
        src="https://i.ibb.co/TDcZWLYr/logo.png" 
        alt="Sakura Bistrô Logo" 
        width={50} 
        height={50} 
        className="rounded-lg"
      />
      <span className="text-2xl font-bold text-sakura-vermelho tracking-wider">
        Sakura Bistrô
      </span>
    </div>
  );
};

export default Logo;
