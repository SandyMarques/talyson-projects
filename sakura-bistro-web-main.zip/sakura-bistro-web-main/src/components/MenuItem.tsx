
import { useCart } from "@/contexts/CartContext";
import { Button } from "./ui/button";
import { ShoppingCart } from "lucide-react";

interface MenuItemProps {
  image: string;
  alt: string;
  title: string;
  description: string;
  price: string;
}

const MenuItem = ({ image, alt, title, description, price }: MenuItemProps) => {
  const { addItem } = useCart();
  const priceNumber = Number(price.replace("R$ ", "").replace(",", "."));

  const handleAddToCart = () => {
    addItem({
      id: title, // Using title as id for simplicity
      title,
      price: priceNumber,
      image
    });
  };

  return (
    <article className="bg-sakura-rosa rounded-xl overflow-hidden shadow-md card-hover">
      <div className="relative overflow-hidden">
        <img 
          src={image}
          alt={alt}
          width="800"
          height="533"
          className="w-full h-48 object-cover transition-transform duration-500 hover:scale-105"
          loading="lazy"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/30 to-transparent opacity-0 hover:opacity-100 transition-opacity duration-300"></div>
      </div>
      
      <div className="p-4 md:p-5">
        <h3 className="text-xl font-semibold mb-2">{title}</h3>
        <p className="text-sm text-sakura-cinza/80 mb-3">{description}</p>
        <div className="flex justify-between items-center">
          <p className="text-lg font-bold text-sakura-vermelho">{price}</p>
          <Button onClick={handleAddToCart} size="sm">
            <ShoppingCart className="w-4 h-4 mr-2" />
            Adicionar
          </Button>
        </div>
      </div>
    </article>
  );
};

export default MenuItem;
