const Hero = () => {
  return (
    <section 
      className="relative h-[70vh] flex items-center justify-center text-center overflow-hidden"
      aria-label="Imagem promocional"
    >
      <img
        src="https://ibb.co/fVf6nmdD" // substitua com o seu link real!
        alt="Animação de comida japonesa"
        className="absolute inset-0 w-full h-full object-cover opacity-70"
      />
      
      <div className="absolute inset-0 bg-black/45 z-10"></div>

      <div className="container mx-auto px-4 relative z-20 max-w-4xl">
        <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold text-sakura-marfim tracking-wider leading-tight animate-fade-in">
          Sabor autêntico do Japão no coração da sua cidade
        </h1>
        
        <div className="mt-6 md:mt-8 animate-fade-in" style={{animationDelay: '0.2s'}}>
          <a 
            href="#menu" 
            className="inline-block bg-sakura-vermelho text-sakura-marfim px-6 py-3 rounded-full font-semibold transition-all duration-300 hover:bg-sakura-vermelhoDark hover:scale-105"
          >
            Ver Cardápio
          </a>
        </div>
      </div>
    </section>
  );
};

export default Hero;
