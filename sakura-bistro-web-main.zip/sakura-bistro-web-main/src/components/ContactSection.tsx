
import { useState } from 'react';
import { toast } from '@/hooks/use-toast';

const ContactSection = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    message: ''
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Simulate form submission
    console.log(formData);
    toast({
      title: "Mensagem enviada!",
      description: "Entraremos em contato em breve.",
    });
    setFormData({
      name: '',
      email: '',
      phone: '',
      message: ''
    });
  };

  return (
    <section id="contato" className="py-16 md:py-20 bg-gradient-to-b from-sakura-marfim to-sakura-rosa/30">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl md:text-4xl text-sakura-vermelho text-center mb-10 md:mb-12">Pedidos & Contato</h2>
        
        <div className="max-w-3xl mx-auto">
          <div className="bg-white rounded-xl shadow-md overflow-hidden">
            <div className="grid md:grid-cols-5">
              <div className="md:col-span-2 bg-sakura-vermelho text-sakura-marfim p-6 md:p-8">
                <h3 className="text-xl font-bold mb-4">Entre em contato</h3>
                
                <div className="space-y-4">
                  <a href="https://wa.me/5500000000000" target="_blank" rel="noopener" className="flex items-center gap-3 hover:text-sakura-rosa transition-colors">
                    <i className="fa-brands fa-whatsapp text-xl"></i>
                    <span>(00) 00000-0000</span>
                  </a>
                  
                  <a href="mailto:contato@sakurabistro.com" className="flex items-center gap-3 hover:text-sakura-rosa transition-colors">
                    <i className="fa-solid fa-envelope text-xl"></i>
                    <span>contato@sakurabistro.com</span>
                  </a>
                  
                  <div className="flex items-center gap-3">
                    <i className="fa-solid fa-location-dot text-xl"></i>
                    <span>Rua das Cerejeiras, 123<br />Centro - Sua Cidade</span>
                  </div>
                  
                  <div className="flex items-center gap-3">
                    <i className="fa-solid fa-clock text-xl"></i>
                    <div>
                      <p>Seg - Sex: 11h às 23h</p>
                      <p>Sáb - Dom: 12h às 00h</p>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="md:col-span-3 p-6 md:p-8">
                <h3 className="text-xl font-bold mb-4 text-sakura-cinza">Envie sua mensagem</h3>
                
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div>
                    <label htmlFor="name" className="block text-sm font-medium text-sakura-cinza/80 mb-1">Nome</label>
                    <input
                      type="text"
                      id="name"
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      className="w-full px-4 py-2 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-sakura-vermelho focus:border-transparent"
                      required
                    />
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label htmlFor="email" className="block text-sm font-medium text-sakura-cinza/80 mb-1">Email</label>
                      <input
                        type="email"
                        id="email"
                        name="email"
                        value={formData.email}
                        onChange={handleChange}
                        className="w-full px-4 py-2 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-sakura-vermelho focus:border-transparent"
                        required
                      />
                    </div>
                    
                    <div>
                      <label htmlFor="phone" className="block text-sm font-medium text-sakura-cinza/80 mb-1">Telefone</label>
                      <input
                        type="tel"
                        id="phone"
                        name="phone"
                        value={formData.phone}
                        onChange={handleChange}
                        className="w-full px-4 py-2 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-sakura-vermelho focus:border-transparent"
                      />
                    </div>
                  </div>
                  
                  <div>
                    <label htmlFor="message" className="block text-sm font-medium text-sakura-cinza/80 mb-1">Mensagem</label>
                    <textarea
                      id="message"
                      name="message"
                      rows={4}
                      value={formData.message}
                      onChange={handleChange}
                      className="w-full px-4 py-2 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-sakura-vermelho focus:border-transparent"
                      required
                    ></textarea>
                  </div>
                  
                  <div>
                    <button
                      type="submit"
                      className="w-full bg-sakura-vermelho text-sakura-marfim py-3 rounded-lg font-semibold transition-colors hover:bg-sakura-vermelhoDark"
                    >
                      Enviar Mensagem
                    </button>
                  </div>
                </form>
              </div>
            </div>
          </div>
          
          <div className="mt-12 flex flex-wrap gap-4 justify-center">
            <a 
              href="https://wa.me/5500000000000" 
              target="_blank" 
              rel="noopener" 
              aria-label="WhatsApp" 
              className="flex items-center gap-2 bg-sakura-vermelho text-sakura-marfim px-6 py-3 rounded-full font-semibold transition-all duration-300 hover:bg-sakura-vermelhoDark"
            >
              <i className="fa-brands fa-whatsapp"></i> WhatsApp
            </a>
            
            <a 
              href="mailto:contato@sakurabistro.com" 
              aria-label="E-mail" 
              className="flex items-center gap-2 bg-sakura-vermelho text-sakura-marfim px-6 py-3 rounded-full font-semibold transition-all duration-300 hover:bg-sakura-vermelhoDark"
            >
              <i className="fa-solid fa-envelope"></i> E-mail
            </a>
            
            <a 
              href="tel:+5500000000000" 
              aria-label="Telefone" 
              className="flex items-center gap-2 bg-sakura-vermelho text-sakura-marfim px-6 py-3 rounded-full font-semibold transition-all duration-300 hover:bg-sakura-vermelhoDark"
            >
              <i className="fa-solid fa-phone"></i> Ligar
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ContactSection;
